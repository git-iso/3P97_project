package com.example.a3p97_project;

public class ConnectionClass {

    protected static Boolean premium = false;
    protected static Boolean locked = false;

}
