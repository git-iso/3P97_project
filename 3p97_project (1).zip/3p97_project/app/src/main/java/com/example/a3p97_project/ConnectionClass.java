package com.example.a3p97_project;

// This class keeps track of whether a subscription is active or not
public class ConnectionClass {

    protected static Boolean premium = false;
    protected static Boolean locked = false;

}
